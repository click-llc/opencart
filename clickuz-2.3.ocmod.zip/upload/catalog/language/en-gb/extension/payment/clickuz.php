<?php
// Text
$_['text_title'] = 'CLICK';
$_['text_form_title'] = 'Additional information';

$_['entry_phone_number'] = 'Phone number';
$_['entry_phone_number_palceholder'] = 'Please enter your phone number';

$_['entry_email'] = 'Email';
$_['entry_email_placeholder'] = 'Please enter your email';


$_['button_confirm'] = 'Pay with CLICK';
