<?php
// Text
$_['text_title'] = 'CLICK';
$_['text_form_title'] = 'Допольнительная информация';

$_['entry_phone_number'] = 'Номер телефона';
$_['entry_phone_number_palceholder'] = 'Пожалуйста, введите ваш номер телефона';

$_['entry_email'] = 'Email';
$_['entry_email_placeholder'] = 'Пожалуйста введите ваш email';

$_['button_confirm'] = 'Оплатить с помощью CLICK';
