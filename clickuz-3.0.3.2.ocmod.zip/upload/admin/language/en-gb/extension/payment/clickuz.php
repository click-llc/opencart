<?php
// Heading
$_['heading_title']		 = 'CLICK Uzbekistan';

// Text
$_['text_extension']	 = 'Extensions';
$_['text_success']		 = 'Success: You have modified CLICK details!';
$_['text_edit']          = 'Edit CLICK settings';
$_['text_clickuz']	     = '<a href="https://click.uz/" target="_blank"><img src="view/image/payment/click-logo.png" alt="Click" title="Click" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant_id']	        = 'Merchant ID';
$_['entry_merchant_user_id']    = 'Merchant User ID';
$_['entry_service_id']		    = 'Merchant Service ID';
$_['entry_secret_key']          = 'Secret Key';
$_['entry_geo_zone']	        = 'Geo Zone';
$_['entry_status']		        = 'Status';
$_['entry_after_payment_status']= 'Status of order after payment';
$_['entry_sort_order']	        = 'Sort Order';
$_['entry_payment_method']      = 'Payment form appearance';
$_['entry_only_card']           = 'Without redirecting to payment page';
$_['entry_invoicing']           = 'Use payment page';

$_['entry_prepare_url']         = 'Prepare url';
$_['entry_prepare_url_help']    = 'This url used for callbacks from CLICK to your site, please set this url to "Prepare Url" field at your merchant cabinet at <a href="merchant.click.uz">merchant.click.uz</a>';
$_['entry_complete_url']        = 'Complete url';
$_['entry_complete_url_help']   = 'This url used for callbacks from CLICK to your site, please set this url to "Complete Url" field at your merchant cabinet at <a href="merchant.click.uz">merchant.click.uz</a>';


// Error
$_['error_permission']	        = 'Warning: You do not have permission to modify payment CLICK!';
$_['error_merchant_id']		    = 'Field Merchant ID is required!';
$_['error_merchant_user_id']	= 'Field Merchant User ID is required!';
$_['error_service_id']		    = 'Field Service ID required!';
$_['error_secret_key']		    = 'Field Secret key is required!';