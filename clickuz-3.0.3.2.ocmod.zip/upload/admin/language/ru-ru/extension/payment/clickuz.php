<?php
// Heading
$_['heading_title']		 = 'CLICK Узбекистан';

// Text
$_['text_extension']	 = 'Расширения';
$_['text_success']		 = 'Вы успешно сохранили детали CLICK!';
$_['text_edit']          = 'Редактировать настройки CLICK';
$_['text_clickuz']	     = '<a href="https://click.uz/" target="_blank"><img src="view/image/payment/click-logo.png" alt="Click" title="Click" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_merchant_id']	        = 'ИД Мерчанта';
$_['entry_merchant_user_id']    = 'ИД пользователя мерчанта';
$_['entry_service_id']		    = 'ИД Сервиса мерчанта';
$_['entry_secret_key']          = 'Секретный ключ';
$_['entry_geo_zone']	        = 'Гео зоны';
$_['entry_status']		        = 'Статус';
$_['entry_after_payment_status']= 'Статус после оплаты';
$_['entry_sort_order']	        = 'Порядок';
$_['entry_payment_method']      = 'Тип формы оплаты';
$_['entry_only_card']           = 'Без перехода на страницу оплаты';
$_['entry_invoicing']           = 'Использовать страницу оплаты CLICK';

$_['entry_prepare_url']         = 'Адрес проверки';
$_['entry_prepare_url_help']    = 'Этот адрес используется для проверки, пожалуйста вставьте на поле "Адрес проверки" это значение на кабинете поставщика в <a href="merchant.click.uz">merchant.click.uz</a>';
$_['entry_complete_url']        = 'Адрес подтверждения';
$_['entry_complete_url_help']   = 'Этот адрес используется для подтверждения оплаты, пожалуйста вставьте на поле "Адрес результата" это значение на кабинете поставщика в <a href="merchant.click.uz">merchant.click.uz</a>';

// Error
$_['error_permission']	        = 'Вы не имеете права на изменение настройки CLICK!';
$_['error_merchant_id']		    = 'Поле ИД Мерчанта не заполнен!';
$_['error_merchant_user_id']	= 'Поле ИД пользователя мерчанта не заполнен!';
$_['error_service_id']		    = 'Поле ИД сервиса мерчанта не заполнен!';
$_['error_secret_key']		    = 'Поле секретный ключ не заполнен!';