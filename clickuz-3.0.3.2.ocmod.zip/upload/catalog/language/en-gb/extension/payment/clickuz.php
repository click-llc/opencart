<?php
// Text
$_['text_title'] = '<img style="width: 90px;" src="catalog/view/theme/default/image/click-logo.png" alt="ClICK Uzbekistan" title="ClICK Uzbekistan" />';
$_['text_form_title'] = 'Additional information';

$_['entry_phone_number'] = 'Phone number';
$_['entry_phone_number_palceholder'] = 'Please enter your phone number';

$_['entry_email'] = 'Email';
$_['entry_email_placeholder'] = 'Please enter your email';


$_['button_confirm'] = 'Pay with CLICK';
